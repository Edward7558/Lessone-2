﻿// Напишите программу, которая выводит третью цифру заданного числа или сообщает, что третьей цифры нет.
Console.WriteLine ("Введите чиcло");
string a = Console.ReadLine ();
if (a.Length<=2)
    Console.WriteLine ("Третьей цифры нет");
else
    Console.WriteLine ("третья цифра: " +a[2]);